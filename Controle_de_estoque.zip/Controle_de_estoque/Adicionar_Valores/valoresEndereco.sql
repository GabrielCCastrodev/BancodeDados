insert into endereco values('Rua R-23', 'Q. 12', 2, 74310190, 755);
insert into endereco values('T. 10', 'Q. 17', 15, 74730310, 0);
insert into endereco values('Rua da penha', 'Q. 25', 7, 74350310, 944);
insert into endereco values('Avenida planalto', 'Q. 12', 10, 74485692, 0);
insert into endereco values('Rua 2', 'Q. 22', 1, 74555385, 0);
insert into endereco values('Avenida brasil', 'Q. 2', 4, 74485530, 0);
