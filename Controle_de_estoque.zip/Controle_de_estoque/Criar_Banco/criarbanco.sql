create database ControleEstoque;

use ControleEstoque;