insert into produto values(1, 'Banana', true, 6, 1);
insert into produto values(2, 'Maçã', true, 7, 1);
insert into produto values(3, 'Melancia', true, 8, 1);

insert into produto values(4, 'Alface', true, 6, 2);
insert into produto values(5, 'Couve', true, 7, 2);
insert into produto values(6, 'Espinafre', true, 8, 2);

insert into produto values(7, 'Veja', false, 3, 3);
insert into produto values(8, 'Detergente', false, 4, 3);
insert into produto values(9, 'Água Sanitária', false, 5, 3);

insert into produto values(10, 'Máquina de Lavar', false, 9, 4);
insert into produto values(11, 'Geladeira duas portas', false, 9, 4);
insert into produto values(12, 'Cafeteira', false, 9, 4);

insert into produto values(13, 'Jaqueta de Couro', false, 9, 5);
insert into produto values(14, 'Calça Jeans', false, 9, 5);
insert into produto values(15, 'Blusa Roxa', false, 9, 5);