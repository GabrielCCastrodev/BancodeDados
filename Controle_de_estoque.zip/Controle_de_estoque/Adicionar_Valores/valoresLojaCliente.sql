insert into Loja_Cliente values('01234567000155', 'Arthur', 1);
insert into Loja_Cliente values('01234567000155', 'Lucas', 2);
insert into Loja_Cliente values('01234567000155', 'Pedro', 3);
insert into Loja_Cliente values('01234567000155', 'Gabriel', 4);
insert into Loja_Cliente values('01234567000155', 'Nelson Mandela', 5);
insert into Loja_Cliente values('01234567000155', 'José', 7);
insert into Loja_Cliente values('01234567000155', 'Ana', 8);

insert into Loja_Cliente values('98765432000144', 'Arthur', 1);
insert into Loja_Cliente values('98765432000144', 'Lucas', 2);
insert into Loja_Cliente values('98765432000144', 'Pedro', 3);
insert into Loja_Cliente values('98765432000144', 'Gabriel', 4);
insert into Loja_Cliente values('98765432000144', 'Nelson Mandela', 5);
insert into Loja_Cliente values('98765432000144', 'Luis', 6);
insert into Loja_Cliente values('98765432000144', 'Ana', 8);

insert into Loja_Cliente values('01234154000133', 'Arthur', 1);
insert into Loja_Cliente values('01234154000133', 'Lucas', 2);
insert into Loja_Cliente values('01234154000133', 'Gabriel', 4);
insert into Loja_Cliente values('01234154000133', 'Nelson Mandela', 5);
insert into Loja_Cliente values('01234154000133', 'Luis', 6);
insert into Loja_Cliente values('01234154000133', 'José', 7);
insert into Loja_Cliente values('01234154000133', 'Ana', 8);