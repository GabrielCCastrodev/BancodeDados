insert into Loja values(01234567000155,1, 74440080);
insert into Loja values(98765432000144,2, 74969017);
insert into Loja values(01234154000133,3, 75085487);