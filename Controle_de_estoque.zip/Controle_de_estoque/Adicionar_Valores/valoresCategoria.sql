insert into categoria values(1, 'Frutas');
insert into categoria values(2, 'Verduras');
insert into categoria values(3, 'Produtos de limpeza');
insert into categoria values(4, 'Eletrodoméstico');
insert into categoria values(5, 'Roupas');