insert into cidade values (1, 'Goiânia');
insert into cidade values (2, 'Aparecida de Goiânia');
insert into cidade values (3, 'Anapolis');
insert into cidade values (4, 'Rio Verde');