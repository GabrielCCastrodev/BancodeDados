create table Loja(CNPJ varchar(18) not null primary key, Cidade integer not null references cidade(codigo), CEP integer not null references endereco(CEP));
