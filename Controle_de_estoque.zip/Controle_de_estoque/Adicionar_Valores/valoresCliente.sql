insert into Cliente values('Arthur', 1, '395.639.290-63', str_to_date('10/08/2001', '%d/%m/%Y'), 74310190);
insert into Cliente values('Lucas', 2, '369.004.780-34', str_to_date('02/12/1998', '%d/%m/%Y'), 74350310);
insert into Cliente values('Pedro', 3, '006.756.220-50', str_to_date('11/02/2000', '%d/%m/%Y'), 74485692);
insert into Cliente values('Gabriel', 4, '134.705.850-83', str_to_date('10/03/1991', '%d/%m/%Y'), 74485530);
insert into Cliente values('Nelson Mandela', 5, '003.398.470-00', str_to_date('09/11/2003', '%d/%m/%Y'), 74730310);
insert into Cliente values('Luis', 6, '340.992.550-34', str_to_date('30/01/2000', '%d/%m/%Y'), 74555385);
insert into Cliente values('José', 7, '455.654.430-08', str_to_date('22/08/2001', '%d/%m/%Y'), 74730310);
insert into Cliente values('Ana', 8, '603.494.280-26', str_to_date('10/08/1990', '%d/%m/%Y'), 74310190);